UHC Survey Year 2 - paper questionnaires (English)
Version: 20 April 2026 submission to DOH - the baseline the CAPI applications were built from.
One PDF per instrument (F1, F2, F3, F4).
